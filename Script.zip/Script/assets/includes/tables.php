<?php
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (DoughouzForest)
// | @author_url 1: http://www.playtubescript.com
// | @author_url 2: http://codecanyon.net/user/doughouzforest
// | @author_email: wowondersocial@gmail.com
// +------------------------------------------------------------------------+
// | PlayTube - The Ultimate Video Sharing Platform
// | Copyright (c) 2017 PlayTube. All rights reserved.
// +------------------------------------------------------------------------+
define('T_USERS', 'users');
define('T_SESSIONS', 'sessions');
define('T_VIDEOS', 'videos');
define('T_DIS_LIKES', 'likes_dislikes');
define('T_COMMENTS', 'comments');
define('T_COMM_REPLIES', 'comm_replies');
define('T_COMMENTS_LIKES', 'comments_likes');
define('T_SAVED', 'saved_videos');
define('T_SUBSCRIPTIONS', 'subscriptions');
define('T_HISTORY', 'history');
define('T_CONFIG', 'config');
define('T_VIDEO_ADS', 'video_ads');
define('T_ADS', 'site_ads');
define('T_TERMS', 'terms');
define('T_LISTS', 'lists');
define('T_PLAYLISTS', 'play_list');
define('T_WLATER', 'watch_later');
define('T_POSTS', 'pt_posts');
define('T_PAYMENTS', 'payments');
define('T_FIELDS', 'profile_fields');
define('T_USR_PROF_FIELDS', 'usr_prof_fields');
define('T_USR_ADS', 'user_ads');
define('T_WITHDRAWAL_REQUESTS', 'withdrawal_requests');
define('T_VERIF_REQUESTS', 'verification_requests');
define('T_ANNOUNCEMENT_VIEWS', 'announcement_views');
define('T_ANNOUNCEMENTS', 'announcements');
define('T_BANNED_IPS', 'banned');
define('T_NOTIFICATIONS', 'notifications');
define('T_REPORTS', 'reports');
define('T_LANGS', 'langs');
define('T_MESSAGES', 'messages');
define('T_CHATS', 'conversations');
define('T_VIDEOS_TRSNS', 'videos_transactions');
define('T_VIEWS', 'views');
define('T_QUEUE', 'queue');
define('T_ADS_TRANS', 'ads_transactions');
define('T_MOVIES', 'movies');
define('T_BLOCK', 'block');
define('T_CUSTOM_PAGES', 'custom_pages');
define('T_BANK_TRANSFER', 'bank_receipts');
define('T_COPYRIGHT', 'copyright_report');
define('T_MON_REQUESTS', 'monetization_requests');
define('T_UPLOADED', 'uploaded_videos');
define('T_PLAYLIST_SUB', 'playlist_subscribers');
define('T_INVITATIONS', 'admininvitations');
define('T_ACTIVITES', 'activities');
define('T_LIVE_SUB', 'live_sub_users');
define('T_CARDS', 'cards');
define('T_FAQS', 'faqs');
?>
