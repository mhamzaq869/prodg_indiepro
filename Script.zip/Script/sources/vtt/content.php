<?php
header("Content-Type:text/vtt;charset=utf-8");
?>
<?php exit();?>
